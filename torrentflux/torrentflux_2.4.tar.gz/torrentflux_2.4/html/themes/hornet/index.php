<?php

$cfg["main_bgcolor"] = "#888777";
$cfg["table_data_bg"] = "#FCF8D8";
$cfg["table_border_dk"] = "#919100";
$cfg["table_header_bg"] = "#b5b56a";
$cfg["table_admin_border"] = "#ffffff";
$cfg["body_data_bg"] = "#e4e4c9";

// Directory alternating colors for dir.php
$cfg["bgLight"] = "#ececec";
$cfg["bgDark"] = "#c8c8c8";

?>