<?php

$cfg["main_bgcolor"] = "#2f5e5e";
$cfg["table_data_bg"] = "#e2f1f1";
$cfg["table_border_dk"] = "#366d6d";
$cfg["table_header_bg"] = "#63b1b1";
$cfg["table_admin_border"] = "#FFFFFF";
$cfg["body_data_bg"] = "#c7e2e2";

// Directory alternating colors for dir.php
$cfg["bgLight"] = "#e2f1f1";
$cfg["bgDark"] = "#a0cfcf";

?>