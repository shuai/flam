<?PHP

$cfg["main_bgcolor"] = "#D9D8D8";
$cfg["table_data_bg"] = "#F6F6F6";
$cfg["table_border_dk"] = "#EFEFEF";
$cfg["table_header_bg"] = "#EFEFEF";
$cfg["table_admin_border"] = "#FFFFFF";
$cfg["body_data_bg"] = "#EFEFEF";

// Directory alternating colors for dir.php
$cfg["bgLight"] = "#EAEAEA";
$cfg["bgDark"] = "#E2E2E2";

?>