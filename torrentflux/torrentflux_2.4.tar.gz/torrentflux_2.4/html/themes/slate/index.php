<?php

$cfg["main_bgcolor"] = "#606E7C";
$cfg["table_data_bg"] = "#ECEFF1";
$cfg["table_border_dk"] = "#98ADC2";
$cfg["table_header_bg"] = "#98ADC2";
$cfg["table_admin_border"] = "#FFFFFF";
$cfg["body_data_bg"] = "#ECEFF1";

// Directory alternating colors for dir.php
$cfg["bgLight"] = "#E4E7E9";
$cfg["bgDark"] = "#D8DCDE";

?>