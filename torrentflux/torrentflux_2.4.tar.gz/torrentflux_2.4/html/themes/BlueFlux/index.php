<?php

$cfg["main_bgcolor"] = "#829FB5";
$cfg["table_data_bg"] = "#EEEEEE";
$cfg["table_border_dk"] = "#d6dfe6";
$cfg["table_header_bg"] = "#d6dfe6";
$cfg["table_admin_border"] = "#FFFFFF";
$cfg["body_data_bg"] = "#d6dfe6";

// Directory alternating colors for dir.php
$cfg["bgLight"] = "#ececec";
$cfg["bgDark"] = "#e1e1e1";

?>