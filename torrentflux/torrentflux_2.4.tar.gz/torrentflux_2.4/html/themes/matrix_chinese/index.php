<?PHP

$cfg["main_bgcolor"] = "#606060";
$cfg["table_data_bg"] = "#EEEEEE";
$cfg["table_border_dk"] = "#808080";
$cfg["table_header_bg"] = "#c0c0c0";
$cfg["table_admin_border"] = "#FFFFFF";
$cfg["body_data_bg"] = "#DDDDDD";

// Directory alternating colors for dir.php
$cfg["bgLight"] = "#ececec";
$cfg["bgDark"] = "#c8c8c8";

?>