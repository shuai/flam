<?php

$cfg["main_bgcolor"] = "#000000";
$cfg["table_data_bg"] = "#000000";
$cfg["table_border_dk"] = "#0802FF";
$cfg["table_header_bg"] = "#0602AA";
$cfg["table_admin_border"] = "#0802FF";
$cfg["body_data_bg"] = "#000000";

// Directory alternating colors for dir.php
$cfg["bgLight"] = "#3547BA";
$cfg["bgDark"] = "#011BB6";

?>