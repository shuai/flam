<?php

$cfg["main_bgcolor"] = "#e7e7e7";
$cfg["table_data_bg"] = "#ffffff";
$cfg["table_border_dk"] = "#e0e0e0";
$cfg["table_header_bg"] = "#c8d0d3";
$cfg["table_admin_border"] = "#FFFFFF";
$cfg["body_data_bg"] = "#ffffff";

// Directory alternating colors for dir.php
$cfg["bgLight"] = "#ffffff";
$cfg["bgDark"] = "#e0e0e0";


