<?php

$cfg["main_bgcolor"] = "#69583D";
$cfg["table_data_bg"] = "#FFF1BA";
$cfg["table_border_dk"] = "#724D33";
$cfg["table_header_bg"] = "#E9A876";
$cfg["table_admin_border"] = "#724D33";
$cfg["body_data_bg"] = "#BB753E";

// Directory alternating colors for dir.php
$cfg["bgLight"] = "#FFFFCF";
$cfg["bgDark"] = "#FFDEA7";

?>