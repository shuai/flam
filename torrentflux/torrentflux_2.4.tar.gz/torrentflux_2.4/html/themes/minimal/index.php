<?php

$cfg["main_bgcolor"] = "#000000";
$cfg["table_data_bg"] = "#eaeaea";
$cfg["table_border_dk"] = "#b4b4b4";
$cfg["table_header_bg"] = "#b4b4b4";
$cfg["table_admin_border"] = "#FFFFFF";
$cfg["body_data_bg"] = "#b4b4b4";

// Directory alternating colors for dir.php
$cfg["bgLight"] = "#eaeaea";
$cfg["bgDark"] = "#d8d8d8";

?>