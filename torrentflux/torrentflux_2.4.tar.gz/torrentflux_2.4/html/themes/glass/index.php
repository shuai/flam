<?php

$cfg["main_bgcolor"] = "#606E7C";
$cfg["table_data_bg"] = "#E5F4FB";
$cfg["table_border_dk"] = "#B3C6D0";
$cfg["table_header_bg"] = "#B3C6D0";
$cfg["table_admin_border"] = "#FFFFFF";
$cfg["body_data_bg"] = "#E1F5FF";

// Directory alternating colors for dir.php
$cfg["bgLight"] = "#A5E1FE";
$cfg["bgDark"] = "#83D5FD";

?>