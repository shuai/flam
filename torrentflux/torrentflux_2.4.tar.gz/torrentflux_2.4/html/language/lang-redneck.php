<?php

/**************************************************************************/
/* TorrentFlux - PHP Torrent Client
/* ============================================
/*
/* This is the language file with all the system messages
/*
/* If you would like to make a translation, please email qrome@yahoo.com
/* the translated file. Please keep the original text order,
/* and just one message per line, also double check your translation!
/*
/* You need to change the second quoted phrase, not the capital one!
/*
/* If you need to use double quotes (") remember to add a backslash (\),
/* so your entry will look like: This is \"double quoted\" text.
/* And, if you use HTML code, please double check it.
/**************************************************************************/

define("_CHARSET","iso-8859-1");
define("_SELECTFILE","Seleck a To'rent fo' upload");
define("_URLFILE","URL fo' th' To'rent File");
define("_UPLOAD","Put it Der");
define("_GETFILE","Git File");
define("_TORRENTLINKS","To'rent Links");
define("_ONLINE","Attend'n");
define("_OFFLINE","Not Here");
define("_STORAGE","Sto'age");
define("_DRIVESPACE","Sto'age Thingy");
define("_SERVERSTATS","Servah Stats / Huh?");
define("_DIRECTORYLIST","Direcko'y List");
define("_ALL","Umm");
define("_PAGEWILLREFRESH","Git Page Ev'ry");
define("_SECONDS","Seconds");
define("_TURNONREFRESH","Turn ON Page Gitt'n");
define("_TURNOFFREFRESH","Turn OFF Page Gitt'n");
define("_WARNING","HEY!");
define("_DRIVESPACEUSED","Sto'age Unit gittin F-U-L-L! Fry mah hide!");
define("_ADMINMESSAGE","Yo' haf a message fum an administrato' in yer thingy box.");
define("_TORRENTS","To'rents");
define("_UPLOADHISTORY","What's been Happen'n");
define("_MYPROFILE","Edit Mah Stuff");
define("_ADMINISTRATION","Administrashun");
define("_SENDMESSAGETO","Give a haller to");
define("_TORRENTFILE","Th' Damn To'rent");
define("_FILESIZE","File Size");
define("_STATUS","Status");
define("_ADMIN","Admin");
define("_BADFILE","bad file");
define("_DATETIMEFORMAT","m/d/y g:i a");
define("_DATEFORMAT","m/d/y");
define("_ESTIMATEDTIME","Guess'n Time");
define("_DOWNLOADSPEED","Gitt'n Speed");
define("_UPLOADSPEED","Giv'n Speed");
define("_SHARING","Sharin'");
define("_USER","Feller");
define("_DONE","DONE");
define("_INCOMPLETE","AIN'T DONE");
define("_NEW","NEW");
define("_TORRENTDETAILS","To'rent Details");
define("_STOPDOWNLOAD","Stop To'rent Download");
define("_RUNTORRENT","Helter-skelter To'rent");
define("_SEEDTORRENT","Seed To'rent");
define("_DELETE","Delete");
define("_ABOUTTODELETE","Yer about t'delete");
define("_NOTOWNER","Not Owny of To'rent");
define("_AUTHORIZATIONFAILED","Autho'izashun FAILED. Ackshun has been logged, cuss it all t' tarnation.");
define("_MESSAGETOALL","This hyar message was sent t''ALL USERS");
define("_TRYDIFFERENTUSERID","Erro': Try a diffrunt User ID.");
define("_HASBEENUSED","has been used, cuss it all t' tarnation.");
define("_RETURNTOEDIT","Return t'Edit");
define("_ADMINUSERACTIVITY","Administrashun - User Ackivity");
define("_ADMIN_MENU","admin");
define("_ACTIVITY_MENU","ackivity");
define("_LINKS_MENU","links");
define("_NEWUSER_MENU","noo user");
define("_BACKUP_MENU","backup");
define("_ALLUSERS","All Users");
define("_NORECORDSFOUND","NO RECORDS FOUND");
define("_SHOWPREVIOUS","Previous");
define("_SHOWMORE","Show Mo'e");
define("_ACTIVITYSEARCH","Ackivity Search");
define("_FILE","File");
define("_ACTION","Ackshun");
define("_SEARCH","Search");
define("_ACTIVITYLOG","Ackivity Log - Last");
define("_DAYS","Days");
define("_IP","IP");
define("_TIMESTAMP","Time Stamp");
define("_USERDETAILS","Feller Details");
define("_HITS","Hits");
define("_UPLOADACTIVITY","Upload Ackivity");
define("_JOINED","Joined");
define("_LASTVISIT","Last Visit");
define("_USERSACTIVITY","Ackivity");
define("_NORMALUSER","No'mal User");
define("_ADMINISTRATOR","Administrato'");
define("_SUPERADMIN","Super Admin");
define("_EDIT","Edit");
define("_USERADMIN","Administrashun - User Admin");
define("_EDITUSER","Edit User");
define("_UPLOADPARTICIPATION","Upload Participashun");
define("_UPLOADS","Uploads");
define("_PERCENTPARTICIPATION","Percent Participashun");
define("_PARTICIPATIONSTATEMENT","Participashun an' Uploads based on th' last");
define("_TOTALPAGEVIEWS","Total Page Views");
define("_THEME","Theme");
define("_USERTYPE","User Type");
define("_NEWPASSWORD","Noo Passwo'd");
define("_CONFIRMPASSWORD","Confirm Passwo'd");
define("_HIDEOFFLINEUSERS","Hide Offline Users on Home Page");
define("_UPDATE","Update");
define("_USERIDREQUIRED","User ID is required, cuss it all t' tarnation.");
define("_PASSWORDLENGTH","Passwo'd muss haf 6 o' mo'e chareeckers.");
define("_PASSWORDNOTMATCH","Passwo'ds does not match.");
define("_PLEASECHECKFOLLOWING","Please check th' follerin'");
define("_NEWUSER","Noo User");
define("_PASSWORD","Passwo'd");
define("_CREATE","Create");
define("_ADMINEDITLINKS","Administrashun - Edit Links");
define("_FULLURLLINK","Full URL Link");
define("_BACKTOPARRENT","Back Parrent Direcko'y");
define("_DOWNLOADDETAILS","Download Details");
define("_PERCENTDONE","Percent Done");
define("_RETURNTOTORRENTS","Return t'To'rents");
define("_DATE","Date");
define("_WROTE","wrote");
define("_SENDMESSAGETITLE","Send a Message");
define("_TO","To");
define("_FROM","Fum");
define("_YOURMESSAGE","Yer Message");
define("_SENDTOALLUSERS","Send t'All Users");
define("_FORCEUSERSTOREAD","Fo'ce User(s) t'Read");
define("_SEND","Send");
define("_PROFILE","Profile");
define("_PROFILEUPDATEDFOR","Profile Updated fo'");
define("_REPLY","Holler Back");
define("_MESSAGE","Message");
define("_MESSAGES","Messages");
define("_RETURNTOMESSAGES","Return t'Messages");
define("_COMPOSE","Pick'm");
define("_LANGUAGE","Speak");


define("_CURRENTDOWNLOAD","Current Download");
define("_CURRENTUPLOAD","Current Upload");
define("_SERVERLOAD","Server Load");
define("_FREESPACE","Free Space");
define("_UPLOADED", "Uploaded");

define("_QMANAGER_MENU","queue");
define("_SETTINGS_MENU","settings");
define("_SEARCHSETTINGS_MENU","search settings");
define("_ERRORSREPORTED","Errors");
define("_STARTED", "Started");
define("_ENDED", "Ended");
define("_QUEUED","Queued");
define("_DELQUEUE","Remove from Queue");
define("_FORCESTOP","Kill Torrent");
define("_STOPPING","Stopping");
define("_COOKIE_MENU","cookies");

?>